public class Product {
    public String name; public double price; public int stock;
    public Product(String name,double price,int stock){this.name=name;this.price=price;this.stock=stock;}
    public String toString(){ return name + ":" + stock; }
}
