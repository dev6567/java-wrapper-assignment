import java.util.*;
public class InventorySystem {
    public static void main(String[] args) {
        Set<String> products = new HashSet<>();
        List<Product> catalog = new ArrayList<>();
        Queue<Product> restock = new LinkedList<>();
        Stack<Product> restocked = new Stack<>();
        Product p1 = new Product("Milk", 40, 2);
        Product p2 = new Product("Bread", 20, 10);
        products.add(p1.name); products.add(p2.name);
        catalog.add(p1); catalog.add(p2);
        // identify low stock
        for (Product p : catalog) if (p.stock < 5) { restock.add(p); }
        while (!restock.isEmpty()) {
            Product r = restock.remove();
            r.stock += 20; restocked.push(r); System.out.println("Restocked: " + r);
        }
        // undo recent restock
        if (!restocked.isEmpty()) {
            Product last = restocked.pop(); last.stock -= 20; System.out.println("Undo restock: " + last);
        }
    }
}
