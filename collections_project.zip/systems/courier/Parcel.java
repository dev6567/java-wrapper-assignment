public class Parcel { public String id; public int priority; public Parcel(String id,int priority){this.id=id;this.priority=priority;} public String toString(){ return id + ":p" + priority; } }
