import java.util.*;
public class CourierSystem {
    public static void main(String[] args) {
        PriorityQueue<Parcel> pq = new PriorityQueue<>((a,b)->Integer.compare(b.priority,a.priority));
        Set<String> assigned = new HashSet<>();
        List<Parcel> completed = new ArrayList<>();
        Queue<Parcel> normal = new LinkedList<>();
        Parcel p1 = new Parcel("P1",5); Parcel p2 = new Parcel("P2",1);
        pq.add(p1); normal.add(p2);
        while (!pq.isEmpty()) { Parcel p = pq.poll(); if (assigned.add(p.id)) completed.add(p); }
        while (!normal.isEmpty()) { Parcel p = normal.poll(); if (assigned.add(p.id)) completed.add(p); }
        System.out.println("Completed: " + completed);
    }
}
