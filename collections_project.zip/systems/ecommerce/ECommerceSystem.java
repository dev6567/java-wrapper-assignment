import java.util.*;
public class ECommerceSystem {
    private List<Order> all = new ArrayList<>(); 
    private Set<Order> unique = new HashSet<>();
    private Queue<Order> processing = new LinkedList<>();
    private Deque<Order> failed = new ArrayDeque<>(); // stack-like for failed orders
    public void addOrder(Order o) { all.add(o); unique.add(o); processing.add(o); }
    public void removeDuplicates() {
        // Rebuild processing queue from unique set preserving order of first occurrence
        processing.clear();
        Set<String> seen = new HashSet<>();
        for (Order o : all) if (seen.add(o.orderId)) processing.add(o);
    }
    public void processOrders() {
        while (!processing.isEmpty()) {
            Order o = processing.remove();
            if (o.orderId.endsWith("F")) { o.failed = true; failed.push(o); System.out.println("Failed: "+o); }
            else System.out.println("Processed: "+o);
        }
    }
    public void reprocessFailed() {
        while (!failed.isEmpty()) {
            Order o = failed.pop();
            o.failed=false; System.out.println("Reprocessed: "+o);
        }
    }
    public static void main(String[] args) {
        ECommerceSystem sys = new ECommerceSystem();
        sys.addOrder(new Order("O1","ItemA"));
        sys.addOrder(new Order("O2","ItemB"));
        sys.addOrder(new Order("O1","ItemA-duplicate"));
        sys.addOrder(new Order("O3F","ItemC-fail"));
        sys.removeDuplicates();
        sys.processOrders();
        sys.reprocessFailed();
    }
}
