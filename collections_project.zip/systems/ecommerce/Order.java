public class Order {
    public String orderId;
    public String details;
    public boolean failed=false;
    public Order(String id, String details){ this.orderId=id; this.details=details; }
    @Override public boolean equals(Object o){ return o instanceof Order && orderId.equals(((Order)o).orderId); }
    @Override public int hashCode(){ return orderId.hashCode(); }
    @Override public String toString(){ return orderId + ":" + details; }
}
