public class Transaction {
    public String id; public String accountId; public double amount;
    public Transaction(String id,String accountId,double amount){this.id=id;this.accountId=accountId;this.amount=amount;}
    public String toString(){ return id + " -> " + accountId + ":" + amount; }
}
