public class Account {
    public String id; public double balance;
    public Account(String id,double balance){this.id=id;this.balance=balance;}
    @Override public boolean equals(Object o){ return o instanceof Account && id.equals(((Account)o).id); }
    @Override public int hashCode(){ return id.hashCode(); }
    public String toString(){ return id + ":" + balance; }
}
