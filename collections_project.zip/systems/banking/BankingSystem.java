import java.util.*;
public class BankingSystem {
    public static void main(String[] args) {
        List<Transaction> all = new ArrayList<>();
        Queue<Transaction> pending = new LinkedList<>();
        Set<Account> valid = new HashSet<>();
        Deque<Transaction> rollback = new ArrayDeque<>();
        valid.add(new Account("A1",1000));
        valid.add(new Account("A2",2000));
        Transaction t1 = new Transaction("T1","A1",100);
        Transaction t2 = new Transaction("T2","A3",50); // invalid account
        pending.add(t1); pending.add(t2);
        while (!pending.isEmpty()) {
            Transaction t = pending.remove();
            if (valid.contains(new Account(t.accountId,0))) {
                all.add(t); rollback.push(t);
                System.out.println("Executed: " + t);
            } else System.out.println("Invalid account for: " + t);
        }
        // rollback last
        if (!rollback.isEmpty()) {
            Transaction last = rollback.pop();
            System.out.println("Rolled back: " + last);
            all.remove(last);
        }
    }
}
