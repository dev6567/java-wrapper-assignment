import java.util.*;
public class FeedbackSystem {
    public static void main(String[] args) {
        List<String> all = new ArrayList<>(Arrays.asList("Good","Bad","Good","Okay"));
        Set<String> unique = new HashSet<>(all);
        Queue<String> q = new LinkedList<>(unique);
        Stack<String> recent = new Stack<>();
        while (!q.isEmpty()) { String f = q.remove(); recent.push(f); System.out.println("Processed: " + f); }
        System.out.println("Recent: " + recent);
    }
}
