import java.util.*;
public class StreamingSystem {
    public static void main(String[] args) {
        Stack<Movie> history = new Stack<>();
        List<Movie> all = new ArrayList<>();
        Set<String> genres = new HashSet<>();
        Queue<Movie> upNext = new LinkedList<>();
        Movie m1 = new Movie("M1","Action"); Movie m2 = new Movie("M2","Drama");
        upNext.add(m1); upNext.add(m2);
        // watch next
        Movie cur = upNext.remove(); history.push(cur); genres.add(cur.genre);
        System.out.println("History: " + history + ", Genres: " + genres);
    }
}
