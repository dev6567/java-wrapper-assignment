public class Movie { public String id; public String genre; public Movie(String id,String genre){this.id=id;this.genre=genre;} public String toString(){ return id + "(" + genre + ")"; } }
