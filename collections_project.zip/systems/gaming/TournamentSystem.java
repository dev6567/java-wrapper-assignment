import java.util.*;
public class TournamentSystem {
    public static void main(String[] args) {
        Set<Player> players = new HashSet<>();
        Queue<Match> matches = new LinkedList<>();
        List<Result> results = new ArrayList<>();
        TreeSet<Result> leaderboard = new TreeSet<>((a,b)->Integer.compare(b.score,a.score));
        players.add(new Player("P1")); players.add(new Player("P2"));
        matches.add(new Match("M1")); matches.add(new Match("M2"));
        // simulate
        results.add(new Result(new Player("P1"), 100));
        results.add(new Result(new Player("P2"), 80));
        leaderboard.addAll(results);
        System.out.println("Leaderboard: " + leaderboard);
    }
}
