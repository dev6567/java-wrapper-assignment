public class Player {
    public String id; public Player(String id){this.id=id;}
    @Override public boolean equals(Object o){return o instanceof Player && id.equals(((Player)o).id);}
    @Override public int hashCode(){return id.hashCode();}
    public String toString(){ return id; }
}
