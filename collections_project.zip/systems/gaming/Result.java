public class Result { public Player p; public int score; public Result(Player p,int s){this.p=p;this.score=s;} public String toString(){return p + ":" + score;} }
