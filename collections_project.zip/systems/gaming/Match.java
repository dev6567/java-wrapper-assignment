public class Match { public String id; public Match(String id){this.id=id;} public String toString(){return id;} }
