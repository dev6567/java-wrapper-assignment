import java.util.*;
public class HospitalSystem {
    public static void main(String[] args) {
        Set<Patient> admitted = new HashSet<>();
        Queue<Patient> waiting = new LinkedList<>();
        Stack<Patient> discharged = new Stack<>();
        List<Patient> history = new ArrayList<>();
        Patient p1 = new Patient("P1"); Patient p2 = new Patient("P2");
        admitted.add(p1); waiting.add(p1); history.add(p1);
        // treat
        Patient t = waiting.remove(); System.out.println("Treating: " + t);
        discharged.push(t); admitted.remove(t);
        // re-admit from discharged
        if (!discharged.isEmpty()) { Patient r = discharged.pop(); admitted.add(r); System.out.println("Re-admitted: " + r); }
    }
}
