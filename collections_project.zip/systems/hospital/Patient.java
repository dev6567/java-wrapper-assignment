public class Patient { public String id; public Patient(String id){this.id=id;} public String toString(){ return id; } }
