import java.util.*;
public class ExamSystem {
    public static void main(String[] args) {
        List<Question> questions = new ArrayList<>();
        for (int i=1;i<=5;i++) questions.add(new Question("Q"+i));
        Collections.shuffle(questions);
        Set<String> studentIds = new HashSet<>();
        Queue<Student> queue = new LinkedList<>();
        // enroll
        studentIds.add("S1"); queue.add(new Student("S1"));
        studentIds.add("S2"); queue.add(new Student("S2"));
        studentIds.add("S2"); // duplicate ignored in set
        System.out.println("Unique students: " + studentIds);
        // serve queue
        while (!queue.isEmpty()) {
            Student s = queue.remove();
            System.out.println("Serving " + s + " with questions " + questions);
        }
    }
}
