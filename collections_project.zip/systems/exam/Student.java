public class Student {
    public String id;
    public Student(String id){ this.id=id; }
    public String toString(){ return id; }
}
