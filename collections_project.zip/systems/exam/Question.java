public class Question {
    public String q;
    public Question(String q){ this.q=q; }
    public String toString(){ return q; }
}
