public class Team { public String name; public int points; public Team(String name){this.name=name;this.points=0;} public String toString(){return name + "(" + points + ")";} }
