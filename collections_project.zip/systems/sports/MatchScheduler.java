import java.util.*;
public class MatchScheduler {
    public static void main(String[] args) {
        Set<Team> teams = new HashSet<>();
        Queue<String> matches = new LinkedList<>();
        List<String> results = new ArrayList<>();
        TreeSet<Team> leaderboard = new TreeSet<>((a,b)->Integer.compare(b.points,a.points));
        Team t1 = new Team("TeamA"); Team t2 = new Team("TeamB");
        teams.add(t1); teams.add(t2);
        matches.add("TeamA vs TeamB");
        // process
        String m = matches.remove(); results.add(m + ": 2-1"); t1.points += 3;
        leaderboard.add(t1); leaderboard.add(t2);
        System.out.println("Leaderboard: " + leaderboard);
    }
}
