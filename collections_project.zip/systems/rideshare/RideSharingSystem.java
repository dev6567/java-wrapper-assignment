import java.util.*;
public class RideSharingSystem {
    public static void main(String[] args) {
        Queue<RideRequest> pending = new LinkedList<>();
        PriorityQueue<RideRequest> pq = new PriorityQueue<>(); // higher priority first via compareTo
        Set<Driver> drivers = new HashSet<>();
        List<Ride> completed = new ArrayList<>();
        drivers.add(new Driver("D1")); drivers.add(new Driver("D2"));
        RideRequest r1 = new RideRequest("R1",1);
        RideRequest r2 = new RideRequest("R2",5);
        RideRequest r3 = new RideRequest("R3",2);
        pq.add(r1); pq.add(r2); pq.add(r3);
        while (!pq.isEmpty() && !drivers.isEmpty()) {
            RideRequest rr = pq.poll();
            Driver d = drivers.iterator().next();
            drivers.remove(d);
            Ride ride = new Ride(rr,d);
            completed.add(ride);
            System.out.println("Assigned: " + ride);
            // driver becomes available again for simplicity
            drivers.add(d);
        }
        System.out.println("Completed rides: " + completed);
    }
}
