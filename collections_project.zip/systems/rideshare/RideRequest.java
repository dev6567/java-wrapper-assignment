public class RideRequest implements Comparable<RideRequest>{
    public String id; public int priority;
    public RideRequest(String id,int priority){this.id=id;this.priority=priority;}
    @Override public int compareTo(RideRequest o){ return Integer.compare(o.priority,this.priority); }
    public String toString(){ return id+"(p"+priority+")"; }
}
