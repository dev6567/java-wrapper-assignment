public class Ride {
    public RideRequest req; public Driver driver;
    public Ride(RideRequest r, Driver d){ this.req=r; this.driver=d; }
    public String toString(){ return req + " -> " + driver; }
}
