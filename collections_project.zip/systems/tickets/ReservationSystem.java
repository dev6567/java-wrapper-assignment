import java.util.*;
public class ReservationSystem {
    public static void main(String[] args) {
        List<Booking> all = new ArrayList<>();
        Set<String> users = new HashSet<>();
        Queue<Booking> queue = new LinkedList<>();
        PriorityQueue<Booking> pq = new PriorityQueue<>((a,b)-> Boolean.compare(b.vip,a.vip));
        // register users and bookings
        users.add("U1"); all.add(new Booking("B1", false)); queue.add(all.get(0));
        users.add("U2"); Booking b2 = new Booking("B2", true); all.add(b2); pq.add(b2);
        System.out.println("Process queue: " + queue);
        System.out.println("Process VIP priority: " + pq.poll());
    }
}
