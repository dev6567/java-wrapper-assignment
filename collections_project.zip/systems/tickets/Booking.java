public class Booking { public String id; public boolean vip; public Booking(String id, boolean vip){this.id=id;this.vip=vip;} public String toString(){ return id + (vip?":VIP":""); } }
