import java.time.*;
public class InsuranceDemo {
    public static void main(String[] args) {
        InsuranceManager m = new InsuranceManager();
        m.add(new Policy("P1","Alice", LocalDate.now().plusDays(10),"Health",5000));
        m.add(new Policy("P2","Bob", LocalDate.now().plusDays(40),"Auto",3000));
        m.add(new Policy("P3","Carol", LocalDate.now().plusDays(5),"Home",7000));
        m.add(new Policy("P1","AliceDup", LocalDate.now().plusDays(10),"Health",5000)); // duplicate number
        m.listAll();
        System.out.println("Expiring within 30 days: " + m.expiringWithin(30));
        System.out.println("Coverage 'Auto': " + m.byCoverage("Auto"));
        System.out.println("Duplicate policy numbers: " + m.findDuplicates());
        m.performanceTest(1000);
    }
}
