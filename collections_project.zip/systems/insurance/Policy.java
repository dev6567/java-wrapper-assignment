import java.time.LocalDate;
public class Policy implements Comparable<Policy> {
    private String policyNumber;
    private String holderName;
    private LocalDate expiry;
    private String coverageType;
    private double premium;
    public Policy(String policyNumber, String holderName, LocalDate expiry, String coverageType, double premium) {
        this.policyNumber = policyNumber; this.holderName = holderName; this.expiry = expiry;
        this.coverageType = coverageType; this.premium = premium;
    }
    public String getPolicyNumber() { return policyNumber; }
    public String getHolderName() { return holderName; }
    public LocalDate getExpiry() { return expiry; }
    public String getCoverageType() { return coverageType; }
    public double getPremium() { return premium; }
    public String toString() { return policyNumber + ":" + holderName + ":" + expiry + ":" + coverageType + ":" + premium; }
    @Override
    public int compareTo(Policy o) { return this.expiry.compareTo(o.expiry); }
    @Override public int hashCode() { return policyNumber.hashCode(); }
    @Override public boolean equals(Object o) {
        if (!(o instanceof Policy)) return false;
        return this.policyNumber.equals(((Policy)o).policyNumber);
    }
}
