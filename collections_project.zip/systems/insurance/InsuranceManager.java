import java.util.*;
import java.time.*;
public class InsuranceManager {
    private Set<Policy> hashPolicies = new HashSet<>();
    private Set<Policy> linkedPolicies = new LinkedHashSet<>();
    private Set<Policy> treePolicies = new TreeSet<>(); // sorted by expiry
    public void add(Policy p) {
        hashPolicies.add(p); linkedPolicies.add(p); treePolicies.add(p);
    }
    public void listAll() {
        System.out.println("HashSet: " + hashPolicies);
        System.out.println("LinkedHashSet (insertion order): " + linkedPolicies);
        System.out.println("TreeSet (sorted by expiry): " + treePolicies);
    }
    public List<Policy> expiringWithin(int days) {
        List<Policy> res = new ArrayList<>();
        LocalDate now = LocalDate.now();
        for (Policy p : hashPolicies) if (!p.getExpiry().isBefore(now) && !p.getExpiry().isAfter(now.plusDays(days))) res.add(p);
        return res;
    }
    public List<Policy> byCoverage(String coverage) {
        List<Policy> res = new ArrayList<>();
        for (Policy p : hashPolicies) if (p.getCoverageType().equalsIgnoreCase(coverage)) res.add(p);
        return res;
    }
    public Set<String> findDuplicates() {
        Set<String> seen = new HashSet<>(), dup = new HashSet<>();
        for (Policy p : hashPolicies) {
            if (!seen.add(p.getPolicyNumber())) dup.add(p.getPolicyNumber());
        }
        return dup;
    }
    // simple performance sample (not rigorous)
    public void performanceTest(int n) {
        long t1 = System.nanoTime();
        for (int i=0;i<n;i++) hashPolicies.contains(new Policy("X"+i,"a",LocalDate.now(),"A",10));
        long t2 = System.nanoTime();
        for (int i=0;i<n;i++) linkedPolicies.contains(new Policy("X"+i,"a",LocalDate.now(),"A",10));
        long t3 = System.nanoTime();
        for (int i=0;i<n;i++) treePolicies.contains(new Policy("X"+i,"a",LocalDate.now(),"A",10));
        long t4 = System.nanoTime();
        System.out.println("HashSet contains calls ns: " + (t2-t1));
        System.out.println("LinkedHashSet contains calls ns: " + (t3-t2));
        System.out.println("TreeSet contains calls ns: " + (t4-t3));
    }
}
