import java.util.*;
public class LibrarySystem {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        Set<String> members = new HashSet<>();
        Queue<Book> issueQueue = new LinkedList<>();
        Stack<Book> returned = new Stack<>();
        books.add(new Book("B1","Java")); members.add("M1");
        issueQueue.add(books.get(0));
        Book toIssue = issueQueue.remove(); System.out.println("Issued: " + toIssue);
        returned.push(toIssue);
        Book reissue = returned.pop(); System.out.println("Re-issued: " + reissue);
    }
}
