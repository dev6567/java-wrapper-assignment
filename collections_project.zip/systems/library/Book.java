public class Book { public String id; public String title; public Book(String id,String title){this.id=id;this.title=title;} public String toString(){ return id + ":" + title; } }
