public class Applicant {
    public String id; public double marks;
    public Applicant(String id,double marks){this.id=id;this.marks=marks;}
    @Override public String toString(){ return id + ":" + marks; }
    @Override public boolean equals(Object o){ return o instanceof Applicant && id.equals(((Applicant)o).id); }
    @Override public int hashCode(){ return id.hashCode(); }
}
