import java.util.*;
public class AdmissionSystem {
    public static void main(String[] args) {
        List<Applicant> all = new ArrayList<>();
        Set<Applicant> shortlisted = new HashSet<>();
        Queue<Applicant> interview = new LinkedList<>();
        TreeSet<Applicant> merit = new TreeSet<>((a,b)->Double.compare(b.marks,a.marks));
        all.add(new Applicant("A1",85)); all.add(new Applicant("A2",78)); all.add(new Applicant("A3",92));
        // shortlist those with marks >=80
        for (Applicant a : all) if (a.marks >= 80) { shortlisted.add(a); interview.add(a); }
        while (!interview.isEmpty()) merit.add(interview.remove());
        System.out.println("Merit list: " + merit);
    }
}
