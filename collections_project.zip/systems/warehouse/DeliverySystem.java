import java.util.*;
public class DeliverySystem {
    public static void main(String[] args) {
        Queue<PackageItem> pending = new LinkedList<>();
        Set<String> ids = new HashSet<>();
        List<PackageItem> delivered = new ArrayList<>();
        Stack<PackageItem> returned = new Stack<>();
        PackageItem p1 = new PackageItem("PK1"); PackageItem p2 = new PackageItem("PK2");
        pending.add(p1); pending.add(p2);
        while (!pending.isEmpty()) {
            PackageItem p = pending.remove();
            if (ids.add(p.id)) { delivered.add(p); System.out.println("Delivered: " + p); } else System.out.println("Duplicate ID: " + p);
        }
        // returned
        returned.push(p2);
        System.out.println("Returned stack: " + returned);
    }
}
