import java.util.*;
public class TriageSystem {
    static class Patient {
        String name; int severity;
        Patient(String n,int s){name=n;severity=s;}
        public String toString(){return name+"("+severity+")";}
    }
    public static void main(String[] args) {
        PriorityQueue<Patient> pq = new PriorityQueue<>((a,b)->Integer.compare(b.severity,a.severity));
        pq.add(new Patient("John",3)); pq.add(new Patient("Alice",5)); pq.add(new Patient("Bob",2));
        while (!pq.isEmpty()) System.out.println("Treat: " + pq.remove());
    }
}
