import java.util.*;
public class CircularBuffer<T> {
    private Object[] arr;
    private int capacity, start=0, count=0;
    public CircularBuffer(int capacity) { this.capacity = capacity; arr = new Object[capacity]; }
    public void insert(T x) {
        if (count < capacity) {
            arr[(start+count)%capacity] = x; count++;
        } else {
            // overwrite oldest
            arr[start] = x; start = (start+1)%capacity;
        }
    }
    public List<T> toList() {
        List<T> res = new ArrayList<>();
        for (int i=0;i<count;i++) res.add((T)arr[(start+i)%capacity]);
        return res;
    }
    public static void main(String[] args) {
        CircularBuffer<Integer> b = new CircularBuffer<>(3);
        b.insert(1); b.insert(2); b.insert(3);
        b.insert(4);
        System.out.println(b.toList()); // [2,3,4]
    }
}
