import java.util.*;
public class StackUsingQueues {
    static class MyStack<T> {
        Queue<T> q1 = new LinkedList<>(), q2 = new LinkedList<>();
        public void push(T x) { q1.add(x); }
        public T pop() {
            while (q1.size() > 1) q2.add(q1.remove());
            T res = q1.remove();
            Queue<T> tmp = q1; q1 = q2; q2 = tmp;
            return res;
        }
        public T top() { T val = pop(); push(val); return val; }
        public boolean isEmpty() { return q1.isEmpty(); }
    }
    public static void main(String[] args) {
        MyStack<Integer> s = new MyStack<>();
        s.push(1); s.push(2); s.push(3);
        System.out.println(s.pop()); // 3
    }
}
