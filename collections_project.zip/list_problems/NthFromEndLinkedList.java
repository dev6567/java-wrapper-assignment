import java.util.*;
public class NthFromEndLinkedList {
    public static <T> T nthFromEnd(LinkedList<T> list, int n) {
        Iterator<T> it1 = list.iterator();
        Iterator<T> it2 = list.iterator();
        int count = 0;
        while (count < n && it2.hasNext()) { it2.next(); count++; }
        if (count < n) throw new IllegalArgumentException("N is larger than list size");
        while (it2.hasNext()) { it2.next(); it1.next(); }
        return it1.next();
    }
    public static void main(String[] args) {
        LinkedList<String> l = new LinkedList<>(Arrays.asList("A","B","C","D","E"));
        System.out.println(nthFromEnd(l,2)); // D
    }
}
