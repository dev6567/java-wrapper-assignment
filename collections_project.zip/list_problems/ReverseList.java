import java.util.*;
public class ReverseList {
    // Reverse ArrayList in-place without Collections.reverse
    public static <T> void reverseArrayList(List<T> list) {
        int i = 0, j = list.size() - 1;
        while (i < j) {
            T temp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, temp);
            i++; j--;
        }
    }
    // Reverse LinkedList using two-pointer iteration
    public static <T> void reverseLinkedList(LinkedList<T> list) {
        int n = list.size();
        for (int i = 0; i < n/2; i++) {
            T a = list.get(i);
            T b = list.get(n-1-i);
            list.set(i, b);
            list.set(n-1-i, a);
        }
    }
    public static void main(String[] args) {
        List<Integer> a = new ArrayList<>(Arrays.asList(1,2,3,4,5));
        reverseArrayList(a);
        System.out.println("Reversed ArrayList: " + a);
        LinkedList<Integer> l = new LinkedList<>(Arrays.asList(1,2,3,4,5));
        reverseLinkedList(l);
        System.out.println("Reversed LinkedList: " + l);
    }
}
