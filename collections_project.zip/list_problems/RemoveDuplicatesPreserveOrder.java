import java.util.*;
public class RemoveDuplicatesPreserveOrder {
    public static <T> List<T> removeDuplicates(List<T> list) {
        Set<T> seen = new LinkedHashSet<>();
        List<T> res = new ArrayList<>();
        for (T x : list) if (seen.add(x)) res.add(x);
        return res;
    }
    public static void main(String[] args) {
        List<Integer> in = Arrays.asList(3,1,2,2,3,4);
        System.out.println(removeDuplicates(in));
    }
}
