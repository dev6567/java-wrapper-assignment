import java.util.*;
public class SymmetricDifference {
    public static <T> Set<T> symmetric(Set<T> a, Set<T> b) {
        Set<T> res = new HashSet<>(a);
        res.addAll(b);
        Set<T> tmp = new HashSet<>(a);
        tmp.retainAll(b);
        res.removeAll(tmp);
        return res;
    }
    public static void main(String[] args) {
        Set<Integer> s1 = new HashSet<>(Arrays.asList(1,2,3));
        Set<Integer> s2 = new HashSet<>(Arrays.asList(3,4,5));
        System.out.println(symmetric(s1,s2));
    }
}
