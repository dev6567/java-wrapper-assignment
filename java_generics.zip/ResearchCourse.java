public class ResearchCourse extends CourseType {
    public ResearchCourse(String t) { super(t); }
}
