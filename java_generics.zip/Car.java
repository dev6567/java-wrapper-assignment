public class Car {
    private String model;
    public Car(String m) { this.model = m; }
    public String toString() { return "Car(" + model + ")"; }
}
