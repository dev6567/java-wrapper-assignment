import java.util.*;
public class FleetManager<T extends Vehicle> {
    private List<T> fleet = new ArrayList<>();
    public void addVehicle(T vehicle) { fleet.add(vehicle); }
    public void showFleet() {
        for (T v : fleet) System.out.println(v);
    }
}
