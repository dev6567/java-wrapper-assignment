public class Meal<T extends MealPlan> {
    private T plan;
    public Meal(T plan) { this.plan = plan; }
    public void generate() { System.out.println("Generating meal: " + plan.getPlanName()); }
    public static <T extends MealPlan> void validateAndGenerate(T plan) {
        System.out.println("Validated: " + plan.getPlanName());
    }
}
