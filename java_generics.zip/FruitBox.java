import java.util.*;
public class FruitBox<T extends Fruit> {
    private List<T> fruits = new ArrayList<>();
    public void add(T fruit) { fruits.add(fruit); }
    public void display() {
        for (T f : fruits) System.out.println(f);
    }
}
