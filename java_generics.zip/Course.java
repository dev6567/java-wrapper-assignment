import java.util.*;
public class Course<T extends CourseType> {
    private T type;
    public Course(T type) { this.type = type; }
    public T getType() { return type; }
    public static void printCourses(List<? extends CourseType> courses) {
        for (CourseType c : courses) System.out.println(c);
    }
}
