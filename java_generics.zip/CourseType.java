public abstract class CourseType {
    private String title;
    public CourseType(String t) { this.title = t; }
    public String getTitle() { return title; }
    public String toString() { return getClass().getSimpleName() + "(" + title + ")"; }
}
