import java.util.*;
public class Demo {
    public static void main(String[] args) {
        System.out.println("=== 1. Box tests ===");
        Box<Integer> b1 = new Box<>(); b1.set(10); System.out.println(b1.get());
        Box<String> b2 = new Box<>(); b2.set("Hello"); System.out.println(b2.get());
        Box<Double> b3 = new Box<>(); b3.set(3.14); System.out.println(b3.get());

        System.out.println("\\n=== 2. Pair test ===");
        Pair<String,Integer> student = new Pair<>("Amol", 20);
        System.out.println(student.getFirst() + " - " + student.getSecond());

        System.out.println("\\n=== 3. isEqual ===");
        System.out.println(Utils.isEqual("a","a"));
        System.out.println(Utils.isEqual(5,6));

        System.out.println("\\n=== 4. maximum ===");
        System.out.println(Utils.maximum(3,7,5));
        System.out.println(Utils.maximum(2.5, 3.1, 1.9));

        System.out.println("\\n=== 5. FruitBox ===");
        FruitBox<Apple> appleBox = new FruitBox<>();
        appleBox.add(new Apple("Red"));
        appleBox.add(new Apple("Green"));
        appleBox.display();

        FruitBox<Mango> mangoBox = new FruitBox<>();
        mangoBox.add(new Mango("Alphonso"));
        mangoBox.display();

        // The following would not compile (uncomment to see): FruitBox<Car> carBox = new FruitBox<>();

        System.out.println("\\n=== 6. sumNumbers ===");
        List<Integer> ints = Arrays.asList(1,2,3);
        List<Double> doubles = Arrays.asList(1.5,2.5);
        System.out.println(Utils.sumNumbers(ints));
        System.out.println(Utils.sumNumbers(doubles));

        System.out.println("\\n=== 7. copyList ===");
        List<Number> dest = new ArrayList<>();
        Utils.copyList(dest, ints);
        Utils.copyList(dest, doubles);
        System.out.println(dest);

        System.out.println("\\n=== 8. Animal hierarchy ===");
        List<Dog> dogs = Arrays.asList(new Dog("Rex"), new Dog("Spot"));
        List<Cat> cats = Arrays.asList(new Cat("Kitty"));
        Utils.printAnimals(dogs);
        Utils.printAnimals(cats);

        System.out.println("\\n=== 9. Cart ===");
        Cart<String> electronicsCart = new Cart<>();
        electronicsCart.addItem("Phone");
        electronicsCart.addItem("Charger");
        electronicsCart.displayItems();

        Cart<String> clothesCart = new Cart<>();
        clothesCart.addItem("T-Shirt");
        clothesCart.displayItems();

        System.out.println("\\n=== 10. Price Calculator ===");
        List<Mobile> mobiles = Arrays.asList(new Mobile("M1", 10000), new Mobile("M2", 12000));
        List<Laptop> laptops = Arrays.asList(new Laptop("L1", 45000));
        System.out.println("Mobiles total: " + Utils.calculateTotal(mobiles));
        System.out.println("Laptops total: " + Utils.calculateTotal(laptops));

        System.out.println("\\n=== 11. FleetManager ===");
        FleetManager<Truck> tm = new FleetManager<>();
        tm.addVehicle(new Truck("T-01"));
        tm.addVehicle(new Truck("T-02"));
        tm.showFleet();
        FleetManager<Bike> bm = new FleetManager<>();
        bm.addVehicle(new Bike("B-01"));
        bm.showFleet();

        System.out.println("\\n=== 12. Smart Warehouse ===");
        Storage<Electronics> s = new Storage<>();
        s.add(new Electronics("E-100"));
        Storage<Furniture> sf = new Storage<>();
        sf.add(new Furniture("F-200"));
        Storage.displayAll(s.getItems());
        Storage.displayAll(sf.getItems());

        System.out.println("\\n=== 13. Dynamic Marketplace ===");
        MarketplaceProduct<String> mp = new MarketplaceProduct<>("Book-A", 200, "Books");
        Discounts.applyDiscount(mp, 10);

        System.out.println("\\n=== 14. Course Management ===");
        ExamCourse ec = new ExamCourse("Math");
        AssignmentCourse ac = new AssignmentCourse("Design");
        List<CourseType> courseTypes = Arrays.asList(ec, ac);
        Course.printCourses(courseTypes);

        System.out.println("\\n=== 15. Meal Plan ===");
        Meal<VegetarianMeal> meal = new Meal<>(new VegetarianMeal());
        meal.generate();
        Meal.validateAndGenerate(new VeganMeal());

        System.out.println("\\n=== 16. Resume Screening ===");
        Resume<SoftwareEngineer> r = new Resume<>(new SoftwareEngineer(), "Alice");
        r.process();
        Resume.processList(Arrays.asList(new SoftwareEngineer(), new DataScientist(), new ProductManager()));
    }
}
