public class MarketplaceProduct<T> extends Product {
    private T category;
    public MarketplaceProduct(String name, double price, T category) { super(name, price); this.category = category; }
    public T getCategory() { return category; }
}
