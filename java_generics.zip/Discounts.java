public class Discounts {
    public static <T extends Product> void applyDiscount(T product, double percentage) {
        double newPrice = product.getPrice() * (1 - percentage/100.0);
        System.out.println("After " + percentage + "% discount, " + product.getName() + " -> " + newPrice);
    }
}
