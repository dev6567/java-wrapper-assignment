public abstract class JobRole {
    private String role;
    public JobRole(String r) { this.role = r; }
    public String getRole() { return role; }
    public String toString() { return getClass().getSimpleName() + "(" + role + ")"; }
}
