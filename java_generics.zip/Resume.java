public class Resume<T extends JobRole> {
    private T role;
    private String candidate;
    public Resume(T role, String candidate) { this.role = role; this.candidate = candidate; }
    public void process() { System.out.println("Processing resume of " + candidate + " for " + role); }
    public static void processList(java.util.List<? extends JobRole> roles) {
        for (JobRole r : roles) System.out.println("Role: " + r);
    }
}
