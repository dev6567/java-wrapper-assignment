import java.util.*;
import java.util.function.Predicate;

class Alert {
    String type;
    String message;

    Alert(String type, String message) {
        this.type = type;
        this.message = message;
    }

    @Override
    public String toString() {
        return "[" + type + "] " + message;
    }
}

public class NotificationFiltering {
    public static void main(String[] args) {
        List<Alert> alerts = List.of(
            new Alert("Emergency", "Patient needs immediate attention!"),
            new Alert("Routine", "Regular health check-up reminder."),
            new Alert("Lab", "Lab results are ready."),
            new Alert("Billing", "Payment pending notice.")
        );

        Predicate<Alert> showOnlyEmergencies = alert -> alert.type.equals("Emergency");
        Predicate<Alert> showOnlyLab = alert -> alert.type.equals("Lab");

        System.out.println("Emergency Alerts:");
        alerts.stream().filter(showOnlyEmergencies).forEach(System.out::println);

        System.out.println("\nLab Alerts:");
        alerts.stream().filter(showOnlyLab).forEach(System.out::println);
    }
}
