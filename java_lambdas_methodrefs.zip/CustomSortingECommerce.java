import java.util.*;

class Product {
    String name;
    double price;
    double rating;
    double discount;

    Product(String name, double price, double rating, double discount) {
        this.name = name;
        this.price = price;
        this.rating = rating;
        this.discount = discount;
    }

    @Override
    public String toString() {
        return name + " | Price: " + price + " | Rating: " + rating + " | Discount: " + discount + "%";
    }
}

public class CustomSortingECommerce {
    public static void main(String[] args) {
        List<Product> products = new ArrayList<>();
        products.add(new Product("Phone", 999.99, 4.5, 10));
        products.add(new Product("Laptop", 1999.99, 4.7, 15));
        products.add(new Product("Headphones", 199.99, 4.2, 5));

        Scanner sc = new Scanner(System.in);
        System.out.println("Sort by: 1-Price, 2-Rating, 3-Discount");
        int choice = sc.nextInt();

        Comparator<Product> comparator = switch (choice) {
            case 1 -> (p1, p2) -> Double.compare(p1.price, p2.price);
            case 2 -> (p1, p2) -> Double.compare(p2.rating, p1.rating);
            case 3 -> (p1, p2) -> Double.compare(p2.discount, p1.discount);
            default -> (p1, p2) -> 0;
        };

        products.sort(comparator);
        products.forEach(System.out::println);
    }
}
