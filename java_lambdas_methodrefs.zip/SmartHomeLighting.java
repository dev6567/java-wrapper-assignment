import java.util.*;

interface LightAction {
    void execute();
}

public class SmartHomeLighting {
    public static void main(String[] args) {
        LightAction motionSensor = () -> System.out.println("Lights ON due to motion detected!");
        LightAction nightMode = () -> System.out.println("Dim lights activated for night mode.");
        LightAction voiceCommand = () -> System.out.println("Lights changed to warm white via voice command.");

        List<LightAction> actions = Arrays.asList(motionSensor, nightMode, voiceCommand);
        actions.forEach(LightAction::execute);
    }
}
