import library.books.*;
import library.members.*;
import library.transactions.*;
public class LibraryMain {
    public static void main(String[] args) {
        Book b = new Book("Java Basics");
        Member m = new Member("Amit");
        Transaction t = new Transaction();
        t.issueBook(b, m);
    }
}
