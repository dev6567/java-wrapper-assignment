import com.company.analytics.sales.*;
import com.company.analytics.hr.*;
public class CompanyMain {
    public static void main(String[] args) {
        SalesReport s = new SalesReport();
        EmployeeReport e = new EmployeeReport();
        s.printReport();
        e.printReport();
        System.out.println("Combined Company Report Completed.");
    }
}
