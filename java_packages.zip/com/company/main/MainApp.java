package com.company.main;
import com.company.hr.*;
import com.company.payroll.*;
public class MainApp {
    public static void main(String[] args) {
        Employee emp = new Employee(1, "Riya", "HR", 50000);
        Payroll p = new Payroll();
        p.calculateBonus(emp);
        System.out.println("Employee: " + emp.getName() + ", Salary after bonus: " + emp.getSalary());
    }
}
