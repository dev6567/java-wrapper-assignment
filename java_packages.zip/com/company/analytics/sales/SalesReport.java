package com.company.analytics.sales;
public class SalesReport {
    public void printReport() {
        System.out.println("Sales Report: Region-wise data printed.");
    }
}
