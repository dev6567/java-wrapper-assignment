package com.school.util;
import com.school.data.Student;
public class Analyzer {
    public double calculateAverage(Student s) {
        return (s.getM1() + s.getM2() + s.getM3()) / 3.0;
    }
    public String findGrade(double avg) {
        if (avg >= 85) return "A";
        else if (avg >= 70) return "B";
        else return "C";
    }
}
