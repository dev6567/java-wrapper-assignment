package com.school.main;
import com.school.data.*;
import com.school.util.*;
public class MainAnalyzer {
    public static void main(String[] args) {
        Student s = new Student("Aarav", 85, 78, 90);
        Analyzer a = new Analyzer();
        double avg = a.calculateAverage(s);
        String grade = a.findGrade(avg);
        System.out.println(s);
        System.out.println("Average: " + avg + ", Grade: " + grade);
    }
}
