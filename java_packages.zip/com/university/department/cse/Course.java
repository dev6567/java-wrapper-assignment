package com.university.department.cse;
public class Course {
    private String courseName;
    public Course(String name) { this.courseName = name; }
    public void showDetails() {
        System.out.println("Course Name: " + courseName);
    }
}
