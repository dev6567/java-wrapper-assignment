import com.university.department.cse.Course;
public class MainAppHierarchy {
    public static void main(String[] args) {
        Course c = new Course("Data Structures");
        c.showDetails();
    }
}
