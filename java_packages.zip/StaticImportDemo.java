import static java.lang.Math.*;
public class StaticImportDemo {
    public static void main(String[] args) {
        double a = 25.0, b = -8.0;
        System.out.println("sqrt(25) = " + sqrt(a));
        System.out.println("pow(2,3) = " + pow(2,3));
        System.out.println("max(4,9) = " + max(4,9));
        System.out.println("min(4,9) = " + min(4,9));
        System.out.println("abs(-8) = " + abs(b));
    }
}
