import college.student.Student;
import college.faculty.Faculty;
public class MainUserPackages {
    public static void main(String[] args) {
        Student s = new Student("Ravi", 101);
        Faculty f = new Faculty("Dr. Mehta", "Physics");
        s.display();
        f.display();
    }
}
