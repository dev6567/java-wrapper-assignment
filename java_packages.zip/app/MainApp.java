import college.student.Student;
public class MainApp {
    public static void main(String[] args) {
        Student s = new Student("Rohan");
        s.display();
    }
}
