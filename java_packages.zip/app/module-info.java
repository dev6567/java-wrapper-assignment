module app {
    requires collegeinfo;
}
