package college.faculty;
public class FacultyMini {
    private String name;
    public FacultyMini(String name) { this.name = name; }
    public void show() { System.out.println("Faculty: " + name); }
}
