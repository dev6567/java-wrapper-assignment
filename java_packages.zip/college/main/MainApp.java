package college.main;
import college.student.*;
import college.faculty.*;
import college.department.*;
import static java.lang.System.out;
public class MainApp {
    public static void main(String[] args) {
        StudentMini s = new StudentMini("Karan");
        FacultyMini f = new FacultyMini("Dr. Nair");
        Department d = new Department("Computer Science");
        out.println("=== College Info ===");
        s.show(); f.show(); d.show();
    }
}
