package college.student;
public class StudentMini {
    private String name;
    public StudentMini(String name) { this.name = name; }
    public void show() { System.out.println("Student: " + name); }
}
